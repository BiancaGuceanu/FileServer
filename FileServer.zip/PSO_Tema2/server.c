#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <signal.h>
#include <ctype.h>
#include <sys/sendfile.h>
#include <libgen.h>

#define SERVERPORT 8080
#define N 5 //numarul de clienti
#define IP_LEN    16
#define MAX_SIZE 1024
#define MAX 2048
#define MAX_FILES 100
#define MAX_WORD_LENGTH 50
#define MAX_WORDS 10
#define SERVER_DIRECTORY "DocumentsServer"
#define LOGGER "logger.txt"

int nowConnectedClients = 0;
int countFiles=0;
int serverRunning=1;
int server_socket;

pthread_mutex_t clientsMutex;
pthread_mutex_t filesMutex;
pthread_mutex_t loggerMutex;

pthread_cond_t commandCondition;
pthread_mutex_t commandMutex;

pthread_t clientThreadID[N];
int threadCount=0;
uint32_t command;

struct Clients
{
    char IP_Address[IP_LEN];
    int socket;
};

typedef struct 
{
    char word[MAX_WORD_LENGTH];
    int frequency;
}WordFrequency;

struct FileInfo 
{
    char filePath[100];
    WordFrequency wordFrequencies[MAX_WORDS];
    int wordCount;
    int wordFound;
};

typedef struct
{
    char command[20];
    char file[200];
    char word[20];
}LoggParam;


struct Clients connectedClients[N];
struct FileInfo filesFromSystem[MAX_FILES];

void modifyLogger(LoggParam param)
{
    char currentPath[MAX_SIZE];
    char filePath[MAX_SIZE];
    if(getcwd(currentPath,sizeof(currentPath))!=NULL){
        strcpy(filePath,currentPath);
        strcat(filePath,"/");
        strcat(filePath,LOGGER);
    }
    else{
        perror("Eroare la fisierul de log.");
        exit(EXIT_FAILURE);
    }

    pthread_mutex_lock(&loggerMutex);

    FILE* logFile=fopen(filePath,"a+");
    if(logFile==NULL){
        perror("Eroare la deschiderea fisierului de log.");
        exit(EXIT_FAILURE);
    }

    time_t t=time(NULL);
    struct tm* tm=localtime(&t);
    char data[64];
    strftime(data,sizeof(data),"%c",tm);
    fprintf(logFile,"Date: %s\n",data);
    fprintf(logFile,"Command: %s\n",param.command);
    if((strcmp(param.command,"LIST")!=0) && (strcmp(param.command,"SEARCH")!=0)){
        fprintf(logFile,"Filepath: %s\n",param.file);
    }
    if(strcmp(param.command,"SEARCH")==0){
        fprintf(logFile,"Word searched: %s\n",param.word);
    }
    fprintf(logFile,"--------------------\n");

    fflush(logFile);
    fclose(logFile);

    pthread_mutex_unlock(&loggerMutex);
}

void handleSignal(int signal)
{
    if(signal==SIGTERM || signal==SIGINT)
    {
        printf("Serverul se inchide...\n");
        serverRunning=0;

        uint32_t cmd=0X40;
        serverRunning=0;
        for (int i = 0; i < nowConnectedClients; i++) {
            uint32_t toSend=htonl(cmd);
            send(connectedClients[i].socket,&toSend,sizeof(toSend),0);
        }
        close(server_socket);
        exit(EXIT_SUCCESS);
    }
}

void* stopApplication(void* arg)
{  
    char stdinput[6];
    struct sigaction sa;
    memset(&sa,0,sizeof(sa));

    sa.sa_flags=SA_RESETHAND;
    sa.sa_handler=handleSignal;
    
    do{
        sigaction(SIGINT, &sa, NULL);
        sigaction(SIGTERM, &sa, NULL);

        fgets(stdinput,sizeof(stdinput),stdin);
        stdinput[strlen(stdinput)-1]='\0';
        if(strcmp(stdinput,"quit")==0){
            printf("Comanda 'quit' a fost introdusa.Serverul se inchide...\n");
            uint32_t cmd=0X40;
            serverRunning=0;
            for (int i = 0; i < nowConnectedClients; i++) {
                uint32_t toSend=htonl(cmd);
                send(connectedClients[i].socket,&toSend,sizeof(toSend),0);
            }
            close(server_socket);
            exit(EXIT_SUCCESS);
        }

    }while(serverRunning);

    return NULL;
}

int compareWordFrequency(const void *a, const void *b) {
    return ((WordFrequency *)b)->frequency - ((WordFrequency *)a)->frequency;
}

void cleanWord(char *word) {

    while (!isalpha(word[0]) && word[0] != '\0') {
        memmove(word, word + 1, strlen(word));
    }

    int len = strlen(word);
    while (len > 0 && !isalpha(word[len - 1])) {
        word[--len] = '\0';
    }

    for (int i = 0; word[i]; i++) {
        word[i] = tolower(word[i]);
    }
}

void extractTopWords(struct FileInfo *fileInfo) {
    FILE *file = fopen(fileInfo->filePath, "r");
    if (!file) {
        fprintf(stderr, "Error opening file: %s\n", fileInfo->filePath);
        return;
    }

    WordFrequency wordFrequencies[MAX_WORDS] = {0};

    char wordBuffer[MAX_WORD_LENGTH];

    while (fscanf(file, "%s", wordBuffer) == 1) {
        cleanWord(wordBuffer);

        for (int i = 0; i < MAX_WORDS; i++) {
            if (strcmp(wordFrequencies[i].word, wordBuffer) == 0) {
                wordFrequencies[i].frequency++;
                break;
            } else if (wordFrequencies[i].frequency == 0) {
                strcpy(wordFrequencies[i].word, wordBuffer);
                wordFrequencies[i].frequency = 1;
                break;
            }
        }
    }

    fclose(file);

    qsort(wordFrequencies, MAX_WORDS, sizeof(WordFrequency), compareWordFrequency);

    for (int i = 0; i < MAX_WORDS && wordFrequencies[i].frequency > 0; i++) {
        strcpy(fileInfo->wordFrequencies[i].word, wordFrequencies[i].word);
        fileInfo->wordFrequencies[i].frequency = wordFrequencies[i].frequency;
        fileInfo->wordCount = i + 1;
    }
}

void makeFilesList(const char *path)
{
    DIR *dir;
    struct dirent *entry;

    if (!(dir = opendir(path))) {
        perror("Eroare la opendir.");
        exit(EXIT_FAILURE);
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR) {
            
            if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                char new_path[PATH_MAX];
                snprintf(new_path, sizeof(new_path), "%s/%s", path, entry->d_name);
                makeFilesList(new_path);
            }
        } else {
            if (countFiles >= MAX_FILES) {
                printf("Numărul maxim de fișiere a fost atins.\n");
                break;
            }

            pthread_mutex_lock(&filesMutex);

            strcpy(filesFromSystem[countFiles].filePath,path);
            strcat(filesFromSystem[countFiles].filePath,"/");
            strcat(filesFromSystem[countFiles].filePath,entry->d_name);
            int cnt=strlen(filesFromSystem[countFiles].filePath);
            filesFromSystem[countFiles].filePath[cnt]='\0';

            countFiles++;
            pthread_mutex_unlock(&filesMutex);
        }
    }

    closedir(dir);
}

void signalFileUpdate() {
    pthread_mutex_lock(&commandMutex);
    pthread_cond_signal(&commandCondition);
    pthread_mutex_unlock(&commandMutex);
}

void* serverThreadFunction(void* arg)
{
    char currentPath[MAX_SIZE];
    if (getcwd(currentPath, sizeof(currentPath)) == NULL) {
        perror("Eroare in obtinerea directorului curent.");
        exit(EXIT_FAILURE);
    }

    char absolutePath[MAX];
    snprintf(absolutePath, sizeof(absolutePath), "%s/%s", currentPath, SERVER_DIRECTORY);

    if (access(absolutePath, F_OK) != 0) {
        perror("Eroare la DocumentsServer.");
        exit(EXIT_FAILURE);
    }

    pthread_mutex_init(&filesMutex, NULL);

    makeFilesList(absolutePath);
    
    pthread_mutex_destroy(&filesMutex);

    pthread_mutex_init(&filesMutex,NULL);

    for(int i=0;i<countFiles;i++){
        extractTopWords(&filesFromSystem[i]);
    }

    pthread_mutex_destroy(&filesMutex);

    pthread_mutex_lock(&commandMutex);

    while(serverRunning)
    {
        pthread_cond_wait(&commandCondition,&commandMutex);
        pthread_mutex_init(&filesMutex, NULL);
        countFiles=0;
        makeFilesList(absolutePath);
        
        pthread_mutex_destroy(&filesMutex);

        pthread_mutex_init(&filesMutex,NULL);

        for(int i=0;i<countFiles;i++){
            extractTopWords(&filesFromSystem[i]);
        }

        pthread_mutex_destroy(&filesMutex);

    }

    pthread_mutex_unlock(&commandMutex);

    
    return NULL;
}

void addClient(struct Clients client)
{
    pthread_mutex_lock(&clientsMutex);

    connectedClients[nowConnectedClients]=client;
    nowConnectedClients++;

    pthread_mutex_unlock(&clientsMutex);
}

char* getIP(int client_socket)
{
    pthread_mutex_lock(&clientsMutex);

    for(int i=0;i<nowConnectedClients;i++){
        if(client_socket==connectedClients[i].socket){
            pthread_mutex_unlock(&clientsMutex);
            return connectedClients[i].IP_Address;
        }
    }
    return NULL;

    pthread_mutex_unlock(&clientsMutex);
}

void LIST_Command(int client_socket)
{
    char fileList[MAX_SIZE];
    char commandBuf[MAX];
    LoggParam param;

    strcpy(fileList,filesFromSystem[0].filePath);
    for(int i=1;i<countFiles;i++){
        strcat(fileList,"*");
        strcat(fileList,filesFromSystem[i].filePath);  
    }

    int dim=strlen(fileList);
    char dimen[4];
    sprintf(dimen,"%d",dim);

    strcpy(commandBuf,dimen);
    strcat(commandBuf,";");
    strcat(commandBuf,fileList);
    
    dim=strlen(commandBuf);
    int sendBytes=send(client_socket,&dim,sizeof(int),0);
    if(sendBytes==-1){
        printf("Eroare la trimiterea dimensiunii comenzii.");
    }
    sendBytes=send(client_socket,commandBuf,dim,0);
    if(sendBytes==-1){
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    }

    char* client_IP=getIP(client_socket);
    printf("Clientul cu adresa IP %s a primit lista de fisiere.\n",client_IP);
    
    
    fflush(stdout);
}

void DOWNLOAD_Command(int client_socket)
{
    int dim=-1;
    LoggParam param;
    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei pentru comanda.");
        exit(EXIT_FAILURE);
    }
    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);
    char* filePath=(char*)malloc(sizeof(char)*dim);
    if(filePath==NULL){
        perror("Eroare la alocarea caii.");
    }
    p=strtok(NULL,";");
    strcpy(filePath,p);
    strcpy(param.file,filePath);
    int fd = open(filePath, O_RDONLY);
    if (fd == -1) {
        perror("Eroare la deschiderea fisierului.");
        free(filePath);
        exit(EXIT_FAILURE);
    }

    struct stat stat_buf;
    fstat(fd, &stat_buf);

    off_t fileSize = stat_buf.st_size;

    if (send(client_socket, &fileSize, sizeof(fileSize), 0) == -1) {
        perror("Eroare la trimiterea dimensiunii fisierului");
        close(fd);
        free(filePath);
        exit(EXIT_FAILURE);
    } 

    off_t offset = 0;
    int sendBytes = sendfile(client_socket, fd, &offset, fileSize);
    if (sendBytes == -1) {
        perror("Eroare la trimiterea fisierului.");
        free(filePath);
        close(fd);
        exit(EXIT_FAILURE);
    }

    char* clientIP=getIP(client_socket);
    printf("S-a trimis fisierul clientului cu adresa IP %s.\n",clientIP);
    strcpy(param.command,"DOWNLOAD");
    modifyLogger(param);
    fflush(stdout);
}

int verifyIfExists(char* directory)
{
    DIR* dir=opendir(directory);
    if(dir){
        closedir(dir);
        return 0;
    }
    else{
        return 1;
    }
    
}

void createDirectory(char* directory)
{
    if(mkdir(directory,0777)==-1){
        perror("Eroare in crearea directorului.");
        exit(EXIT_FAILURE);
    }
}

void UPLOAD_Command(int client_socket)
{
    int dim=-1;
    LoggParam param;

    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei pentru comanda.");
        exit(EXIT_FAILURE);
    }
    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);
    
    char* filePath=(char*)malloc(sizeof(char)*dim);
    if(filePath==NULL){
        perror("Eroare la alocarea caii.");
    }

    p=strtok(NULL,";");
    strcpy(filePath,p);
    strcpy(param.file,filePath);

    char createDir[256];
    strcpy(createDir,filePath);
    char* dir=dirname(createDir);
    
    if(verifyIfExists(dir)==1){
        createDirectory(dir);
    }
   
    p=strtok(NULL,";");
    dim=atoi(p);

    char* content=(char*)malloc(sizeof(char)*dim);
    if(content==NULL){
        perror("Eroare la alocare continut fisier.");
        free(filePath);
        exit(EXIT_FAILURE);
    }
    p=strtok(NULL,";");
    strcpy(content,p);

    FILE* f=fopen(filePath,"w");
    if(f==NULL){
        perror("Eroare la deschiderea fisierului.");
        free(filePath);
        free(content);
        exit(EXIT_FAILURE);
    }

    int bytesWritten=fwrite(content,1,strlen(content),f);
    if(bytesWritten==-1){
        perror("Eroare la scrierea in fisier.");
        fclose(f);
        free(filePath);
        free(content);
    }
    fflush(f);
    fclose(f);
    char* client_IP=getIP(client_socket);
    printf("Clientul %s a incarcat fisierul %s.\n",client_IP,filePath);
    signalFileUpdate();
    strcpy(param.command,"UPLOAD");
    modifyLogger(param);
    fflush(stdout);
    free(commandBuf);
}

void DELETE_Command(int client_socket)
{
    int dim=-1;
    LoggParam param;
    uint32_t statusCommand=0x0;
   
    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei pentru comanda.");
        exit(EXIT_FAILURE);
    }
    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);
    char* filePath=(char*)malloc(sizeof(char)*dim);
    if(filePath==NULL){
        perror("Eroare la alocarea caii.");
    }
    p=strtok(NULL,";");
    strcpy(filePath,p);
    strcpy(param.file,filePath);
  

    if(remove(filePath)==0){
        char* client_IP=getIP(client_socket);
        printf("Clientul %s a sters fisierul %s.\n",client_IP,filePath);
        signalFileUpdate();
        strcpy(param.command,"DELETE");
        modifyLogger(param);
        free(filePath);
        fflush(stdout);
    }
    else{
        printf("Eroare la stergerea fisierului.\n");
        free(filePath);
        statusCommand=0x40;
    }

    uint32_t toSend=htonl(statusCommand);
    send(client_socket,&toSend,sizeof(toSend),0);
    free(commandBuf);
    fflush(stdout);
  
}

void MOVE_Command(int client_socket)
{
    int dim=-1;
    LoggParam param;
    uint32_t statusCommand=0x0;

    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei pentru comanda.");
        exit(EXIT_FAILURE);
    }
    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);

    char* file_to_move=(char*)malloc(sizeof(char)*dim);
    
    if(file_to_move==NULL){
        perror("Eroare la alocarea fisierului.");
        exit(EXIT_FAILURE);
    }
    p=strtok(NULL,";");
    strcpy(file_to_move,p);
    strcpy(param.file,file_to_move);
    
    p=strtok(NULL,";");
    dim=atoi(p);

    char* file_moved=(char*)malloc(sizeof(char)*dim);
    if(file_moved==NULL){
        perror("Eroare la alocarea fisierului.");
        exit(EXIT_FAILURE);
    }  
    p=strtok(NULL,";");
    strcpy(file_moved,p);

    char createDir[256];
    strcpy(createDir,file_moved);
    char* dir=dirname(createDir);
    
    if(verifyIfExists(dir)==1){
        createDirectory(dir);
    }

    if(rename(file_to_move,file_moved)==0){
        char* clientIP=getIP(client_socket);
        printf("Clientul cu adresa IP %s a mutat un fisier.\n",clientIP);
        signalFileUpdate();
        strcpy(param.command,"MOVE");
        fflush(stdout);
    }
    else{
        perror("Eroare la mutarea fisierului.");
        statusCommand=0x40;
    } 

    uint32_t toSend=htonl(statusCommand);
    send(client_socket,&toSend,sizeof(toSend),0);
    free(file_moved);
    free(file_to_move);
    free(commandBuf);
}

void UPDATE_Command(int client_socket)
{
    uint32_t statusCommand=0x0;     
    int dim=-1;
    LoggParam param;
   
    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei pentru comanda.");
        exit(EXIT_FAILURE);
    }
    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);
    char* filePath=(char*)malloc(sizeof(char)*dim);
    
    p=strtok(NULL,";");
    strcpy(filePath,p);
    strcpy(param.file,filePath);
   
    p=strtok(NULL,";");
    int byte=atoi(p);
    p=strtok(NULL,";");
    dim=atoi(p);
    char* content=(char*)malloc(sizeof(char)*dim);
    p=strtok(NULL,";");
    strcpy(content,p);

    FILE* f=fopen(filePath,"r+");
    if(f==NULL){
        perror("Eroare la deschiderea fisierului.");
        free(commandBuf);
        free(content);
        exit(EXIT_FAILURE);
    }

    fseek(f,byte,SEEK_SET);
    fprintf(f,"%s",content);

    fclose(f);
    
    fflush(stdout);
    free(commandBuf);
    free(content);

    char* client_IP=getIP(client_socket);
    printf("Clientul %s a actualizat fisierul %s.\n",client_IP,filePath);

    uint32_t toSend=htonl(statusCommand);
    send(client_socket,&toSend,sizeof(toSend),0);
    signalFileUpdate();
    strcpy(param.command,"UPDATE");
    modifyLogger(param);  
}

void SEARCH_Command(int client_socket)
{
    int dim=-1;
    LoggParam param;

    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei pentru comanda.");
        exit(EXIT_FAILURE);
    }
    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);

    char* searchWord=(char*)malloc(sizeof(char)*dim);
    
    p=strtok(NULL,";");
    strcpy(searchWord,p);  
    
    printf("Searching for word: %s\n", searchWord);

    for (int i = 0; i < countFiles; i++) {
        filesFromSystem[i].wordFound = 0;

        for (int j = 0; j < filesFromSystem[i].wordCount; j++) {
            if (strcmp(filesFromSystem[i].wordFrequencies[j].word, searchWord) == 0) {
                filesFromSystem[i].wordFound = 1;
                break; 
            }
        }

        if (!filesFromSystem[i].wordFound) {
            FILE *file = fopen(filesFromSystem[i].filePath, "r");
            if (!file) {
                fprintf(stderr, "Error opening file: %s\n", filesFromSystem[i].filePath);
                continue;
            }

            char wordBuffer[MAX_WORD_LENGTH];
            while (fscanf(file, "%s", wordBuffer) == 1) {
                cleanWord(wordBuffer);
                if (strcmp(wordBuffer, searchWord) == 0) {
                    filesFromSystem[i].wordFound = 1;
                    break; 
                }
            }
            fclose(file);
        }
    }

    char list[MAX_SIZE];
    memset(list,0,sizeof(list));
    int count=0;

    for (int i = 0; i < countFiles; i++) {
        if ((filesFromSystem[i].wordFound == 1) && (count == 0)) {
            strcpy(list, filesFromSystem[i].filePath);
            strcat(list, "*");
            count++;
        }
        else if ((filesFromSystem[i].wordFound == 1) && (count != 0)){
            strcat(list, filesFromSystem[i].filePath);
            strcat(list, "*");
            count++;
        }
    }
    uint32_t statusCommand;
    if(count==0)
    {
        statusCommand=0x1;
        uint32_t toSend=htonl(statusCommand);
        send(client_socket,&toSend,sizeof(toSend),0);
    }
    else
    {
        statusCommand=0x0;
        uint32_t toSend=htonl(statusCommand);
        send(client_socket,&toSend,sizeof(toSend),0);

        dim=strlen(list);
        char dimen[4];
        sprintf(dimen,"%d",dim);
        char commandL[MAX_SIZE];
        strcpy(commandL,dimen);
        strcat(commandL,";");
        strcat(commandL,list);
    
        dim=strlen(commandL);
        int sendBytes=send(client_socket,&dim,sizeof(int),0);
        if(sendBytes==-1){
            printf("Eroare la trimiterea dimensiunii comenzii.");
        }
        sendBytes=send(client_socket,commandL,dim,0);
        if(sendBytes==-1){
            perror("Eroare la trimiterea comenzii.");
            exit(EXIT_FAILURE);
        }
    }
    
    strcpy(param.command,"SEARCH");
    strcpy(param.word,searchWord);
    modifyLogger(param);
    free(searchWord);
    free(commandBuf);   
}

void* handleClient(void* arg)
{
    int client_socket=*((int*)arg);
    free(arg);

    struct sockaddr_in client_address;
    socklen_t client_address_len=sizeof(client_address);

    if(getpeername(client_socket, (struct sockaddr*)&client_address,&client_address_len)!=0){
        perror("Nu s-a putut obtine adresa IP a clientului.");
        close(client_socket);
        return NULL;
    }

    char clientIP[IP_LEN];
    struct Clients client;
   

    if(inet_ntop(AF_INET,&(client_address.sin_addr),clientIP,IP_LEN)!=NULL){
        printf("Clientul cu adresa IP %s s-a conectat.\n",clientIP);
        uint32_t status=0x0;
        uint32_t toSend=htonl(status);
        send(client_socket,&toSend,sizeof(toSend),0);

        strncpy(client.IP_Address,clientIP,IP_LEN);
        client.socket=client_socket;
    }


    addClient(client);

    pthread_mutex_lock(&clientsMutex);
    if (serverRunning == 0) {
        close(client_socket);
        pthread_mutex_unlock(&clientsMutex);
    }
    pthread_mutex_unlock(&clientsMutex);
    
    while(serverRunning)
    {
        uint32_t recvCmd;
        recv(client_socket,&recvCmd,sizeof(recvCmd),0);
        uint32_t command=ntohl(recvCmd);
        
        if(command==-1){
            printf("Eroare la primirea comenzii.\n");
            exit(EXIT_FAILURE);
        }
        else 
        {
            switch(command)
            {
                case 0x0:
                    LIST_Command(client_socket);
                    break;
                case 0x1:
                    DOWNLOAD_Command(client_socket);
                    break;
                case 0x2:
                    UPLOAD_Command(client_socket);
                    break;
                case 0x4:
                    DELETE_Command(client_socket);
                    break;
                case 0x8:
                    MOVE_Command(client_socket);
                    break;
                case 0x10:
                    UPDATE_Command(client_socket);
                    break;
                case 0x20:
                    SEARCH_Command(client_socket);
                    break;
                default:
                    break;
            }
        }
    }

    close(client_socket);
    return NULL;
}

int main()
{

    server_socket=socket(AF_INET,SOCK_STREAM,0);
    if (server_socket == -1) {
        perror("Eroare la crearea socket-ului");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVERPORT);
    server_address.sin_addr.s_addr = INADDR_ANY;

    
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {  
        perror("Eroare la legarea socket-ului");
        exit(EXIT_FAILURE);
    }
    
    if(listen(server_socket,N)==-1){
        perror("Eroare la ascultarea conexiunilor.");
        exit(EXIT_FAILURE);
    }

    printf("Serverul a fost pornit.\n");

    pthread_t serverThreadID;
    if(pthread_create(&serverThreadID,NULL,serverThreadFunction,NULL)!=0){
        perror("Eroare la crearea thread-ului pentru gestiunea fisierelor.");
        exit(EXIT_FAILURE);
    } 

    pthread_t stopApplicationID;
    if(pthread_create(&stopApplicationID,NULL,stopApplication,NULL)!=0){
        perror("Eroare la crearea thread-ului pentru oprirea aplicatiei.");
        exit(EXIT_FAILURE);
    }

    pthread_mutex_init(&clientsMutex,NULL);
    pthread_mutex_init(&loggerMutex,NULL);

    while(serverRunning)
    {
        struct sockaddr_in client_address;
        socklen_t client_address_len=sizeof(client_address);
        
        int client_socket=accept(server_socket, (struct sockaddr*)&client_address, &client_address_len);
        if (client_socket == -1) {
            perror("Eroare la acceptarea conexiunii de la client.");
            continue;
        }

        int* clientSocketPtr=(int*)malloc(sizeof(int));
        *clientSocketPtr=client_socket;

        if (nowConnectedClients == N) {
        printf("Serverul este full.Clientul nu se poate conecta.\n");
            uint32_t status = 0x8;
            uint32_t toSend = htonl(status);
            send(client_socket, &toSend, sizeof(toSend), 0);
            close(client_socket);
            continue;
        }
        else 
        {     
            if(pthread_create(&clientThreadID[threadCount],NULL,handleClient,clientSocketPtr)==-1){
                perror("Eroare la crearea firului de executie pentru client.");
                free(clientSocketPtr);
                close(client_socket);
                continue;
            }
        threadCount++;
        }
    }


    pthread_mutex_destroy(&clientsMutex);
    pthread_mutex_destroy(&loggerMutex);
    pthread_join(serverThreadID, NULL);
    pthread_join(stopApplicationID,NULL);


    return 0;
}

