Aplicatia mea de tip 'File Sever' este constituita din server si clienti, clienti care pot fi 
in numar de maxim N, numar configurabil.Daca numarul de clienti este depasit, atat serverul cat 
si clientul vor fi anuntati.
Fiecare comanda se introduce sugestiv asa cum este specificat in meniul clientului.Am lasat fisierele
si directoarele de test in fiecare din cele doua directoare.

1.LIST: afiseaza lista tuturor fisierelor care se afla in directorul serverului ('DocumentsSever'),
dar si in subdirectoarele acestuia.Este afisata toata calea catre acestea pentru usurinta
vizualizarii pentru punctele ulterioare.Aceasta lista de fisiere este creata cu ajutorul 
unui thread separat la pornirea serverului si este reinnoita dupa functiile de MOVE,DELETE,UPLOAD
si UPDATE.Pentru a stii cand sa reinnoiasca lista si cuvintele cele mai frecvente din fisier 
am utilizat o variabila conditionata.
Pentru functiile care gasesc cele mai frecvente 10 cuvinte am remodelat niste functii gasite
pe internet, nu mai stiu exact sursa.

2.DOWNLOAD: pentru aceasta functie trebuie tastata intreaga cale catre fisierul care se doreste
a fi downloadat.Calea poate fi a unui fisier aflat in directorul serverului sau orice alt fisier
din calculatorul severului.

3.UPLOAD: in acest caz se pot descarca pe server doar fisiere aflate in directorul DocumentsClient, iar 
pentru alegerea directorului se poate considera un director existent sau unul care va fi creat automat 
la descarcarea fisierului si va deveni un subdirector pentru DocumentsServer.

4.DELETE: se va introduce calea catre un fisier si acesta va fi sters.Daca se introduce o cale
gresita atat serverul cat si clientul vor primi un mesaj de eroare si se va reveni la meniul 
principal.

5.MOVE: se va introduce mai intai calea fisierului care trebuie mutat si apoi doar directorul
in care se doreste a fi mutat.

6.UPDATE: este destul de sugestiv meniul, se introduce calea, octetul de la care se doreste
inlocuirea textului si apoi textul propriu zis.

7.SEARCH: cauta mai intai cuvantul in lista cu cele 10 cuvinte care este de asemenea, configurabila,
apoi cauta in fiecare cuvant din fisier.Daca nu il gaseste, va specifica asta in client, daca il 
gaseste, va afisa lista fisierelor care contin acest cuvant.

In ceea ce priveste inchiderea serverului si a clientilor la cele doua semnale sau quit, am lasat 
comentata secventa din client care ma ajuta la indeplinirea acestui lucru.Am incercat sa lucrez
si pe un thread separat care intr un while infinit sa astepte sa vada daca primeste acest mesaj
de exit, insa imi corupe comenzile din restul aplicatiei acest lucru, nu inteleg exact care este 
problema.

Pe partea serverului, am abordat pe thread-uri diferite oprirea aplicatiei si gestiunea semnalelor,
apoi constuirea listei de fisiere si actualizarea ei la nevoie, cat si gestiunea clientilor pe
cate un thread separat pentru fiecare client.Pentru fisierul de log am folosit o structura si
functii predefinite pentru data si ora, pe care le am utilizat si pentru proiectul la aceasta
materie.