#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <errno.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <pthread.h>


#define SERVERPORT 8080
#define SERVERIP "10.0.2.15"
#define MAX_SIZE 1024
#define MAX 2048
#define BUFFER_SIZE 1024
#define SERVER_DIRECTORY "DocumentsServer"
#define CLIENT_DIRECTORY "DocumentsClient"


int client_socket;
pthread_t sendThread;
int serverRunning=1;

void LIST_Command()
{
    printf("\n---LIST---\n");
    int dim=-1;

    int sentBytes=recv(client_socket,&dim,sizeof(int),0);
    if(sentBytes==-1){
        perror("Eroare la primirea dimensiunii comenzii.\n");
        exit(EXIT_FAILURE);
    }

    char* commandBuf=(char*)malloc(sizeof(char)*dim);
    if(commandBuf==NULL){
        perror("Eroare la alocarea memoriei.");
        exit(EXIT_FAILURE);
    }

    sentBytes=recv(client_socket,commandBuf,dim,0);
    if(sentBytes==-1){
        perror("Eroare la primirea comenzii.");
        exit(EXIT_FAILURE);
    }
    commandBuf[dim]='\0';

    char* p=strtok(commandBuf,";");
    dim=atoi(p);
    char* files=(char*)malloc(sizeof(char)*dim);
    if(files==NULL){
        perror("Eroare la alocarea fisierelor.");
    }
    p=strtok(NULL,";");
    strcpy(files,p);

    p=strtok(files,"*");
    while(p!=NULL){
        printf("%s\n",p);
        p=strtok(NULL,"*");
    }
    
    free(files);
    free(commandBuf);
}

char* getFileNameFromPath(char *path) 
{
    char *filename = strrchr(path, '/');
    if (filename == NULL) {
        return path;
    } else {
        return filename + 1;
    }
}

char* makeFilePathClient(char* fileName)
{
    char currentPath[MAX_SIZE];
    if (getcwd(currentPath, sizeof(currentPath)) == NULL) {
        perror("Eroare in obtinerea directorului curent.");
        exit(EXIT_FAILURE);
    }

    char absolutePath[MAX];
    snprintf(absolutePath, sizeof(absolutePath), "%s/%s/%s", currentPath, CLIENT_DIRECTORY,fileName);
    int dim=strlen(absolutePath);
    absolutePath[dim]='\0';

    char* path=(char*)malloc(sizeof(char)*strlen(absolutePath));
    strcpy(path,absolutePath);

    return path;
}

void DOWNLOAD_Command()
{
    printf("\n---DOWNLOAD---\n");
    printf("Tastati calea fisierului pe care doriti sa-l descarcati:\n");
    char filePath[250];
    int bytesRead = read(0, filePath, sizeof(filePath));
    if (bytesRead == -1) {
        perror("Eroare la citirea caii catre fisier.");
        exit(EXIT_FAILURE);
    }
    filePath[strcspn(filePath, "\n")] = '\0';

    char commandBuf[MAX];
    int dim = strlen(filePath);
    char dimen[5];
    sprintf(dimen, "%d", dim);
    

    strcpy(commandBuf, dimen);
    strcat(commandBuf, ";");
    strcat(commandBuf,filePath);

    dim=strlen(commandBuf);
    int bytesSend = send(client_socket, &dim,sizeof(int), 0);
    if (bytesSend == -1) {
        perror("Eroare la trimiterea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }

    bytesSend = send(client_socket,commandBuf, dim, 0);
    if (bytesSend == -1) {
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    }

    char *name = getFileNameFromPath(filePath);

    char *clientFile = makeFilePathClient(name);

    FILE *f = fopen(clientFile, "wb");
    if (f == NULL) {
        perror("Eroare la deschiderea fisierului.");
        exit(EXIT_FAILURE);
    }

    off_t fileSize;
    ssize_t receivedBytes = recv(client_socket, &fileSize, sizeof(fileSize), 0);
    if (receivedBytes == -1) {
        perror("Eroare la primirea dimensiunii fisierului");
        fclose(f);
        return;
    }

    char buffer[MAX_SIZE];
    ssize_t bytesReadTotal = 0;

    while ((receivedBytes = recv(client_socket, buffer, sizeof(buffer), 0)) > 0) {
        fwrite(buffer, 1, receivedBytes, f);
        bytesReadTotal += receivedBytes;

        if (bytesReadTotal >= fileSize) {
            break; 
        }
    }

    fclose(f); 
}

char* makeFilePathServer(char* directory,char* name)
{
    char* path;
    int dim=0;

    char currentPath[MAX_SIZE];
    if (getcwd(currentPath, sizeof(currentPath)) == NULL) {
        perror("Eroare in obtinerea directorului curent.");
        exit(EXIT_FAILURE);
    }
    char absolutePath[MAX];
    snprintf(absolutePath, sizeof(absolutePath), "%s/%s", currentPath, SERVER_DIRECTORY);
    
    if(strcmp(directory,"DocumentsServer")==0){
        dim=strlen(absolutePath)+strlen(name);
        path=(char*)malloc(sizeof(char)*dim);
        strcpy(path,absolutePath);
        strcat(path,"/");
        strcat(path,name);        
    }
    else{
        dim=strlen(absolutePath)+strlen(name)+strlen(directory);
        path=(char*)malloc(sizeof(char)*dim);
        strcpy(path,absolutePath);
        strcat(path,"/");
        strcat(path,directory);
        strcat(path,"/");
        strcat(path,name);
    }

    return path;
}

void UPLOAD_Command()
{
    char commandBuf[MAX];
    printf("\n---UPLOAD---\n");
    printf("Introduceti numele fisierului pe care doriti sa il incarcati:\n");
    char fileName[250];
    int bytesRead=read(0,fileName,sizeof(fileName));
    if(bytesRead==-1){
        perror("Eroare la citirea numelui fisierului");
        exit(EXIT_FAILURE);
    }
    fileName[strcspn(fileName,"\n")] = '\0';

    printf("In care director doriti sa il incarcati?\n");
    char directory[250];
    bytesRead=read(0,directory,sizeof(directory));
    if(bytesRead==-1){
        perror("Eroare la citirea directorului.");
        exit(EXIT_FAILURE);
    }
    directory[strcspn(directory,"\n")] = '\0';

    char* newPath=makeFilePathServer(directory,fileName);
    int dim=strlen(newPath);
    char dimen[5];
    sprintf(dimen,"%d",dim);
    

    strcpy(commandBuf,dimen);
    strcat(commandBuf,";");
    strcat(commandBuf,newPath);
    strcat(commandBuf,";");
    
    char* absolutePath=makeFilePathClient(fileName);
    
    FILE* f=fopen(absolutePath,"r");
    if(f==NULL){
        perror("Eroare la deschiderea fisierului.");
        exit(EXIT_FAILURE);
    }

    fseek(f,0,SEEK_END);
    int fileDim=ftell(f);
    rewind(f);

    sprintf(dimen,"%d",fileDim);
    strcat(commandBuf,dimen);
    strcat(commandBuf,";");

    char* content=(char*)malloc(sizeof(char)*(fileDim+1));
    if(content==NULL){
        perror("Eroare la alocarea bufferului.");
        fclose(f);
        exit(EXIT_FAILURE);
    }

    int readFromFile=fread(content,1,fileDim,f);
    if(readFromFile!=fileDim){
        perror("Eroare la citirea continutului.");
        fclose(f);
        free(content);
        exit(EXIT_FAILURE);
    }

    content[fileDim]='\0';
    strcat(commandBuf,content);
    
    dim=strlen(commandBuf);
    
    int bytesSend=send(client_socket,&dim,sizeof(int),0);
    if(bytesSend==-1){
        perror("Eroare la trimiterea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    bytesSend=send(client_socket,commandBuf,dim,0);
    if(bytesSend==-1){
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    }

    free(content);
    fclose(f);
}

void DELETE_Command()
{
    char commandBuf[MAX];
    printf("\n---DELETE---\n");
    printf("Introduceti calea fisierului care doriti sa fie sters:\n");
    char filePath[250];
    int bytesRead=read(0,filePath,sizeof(filePath));
    if(bytesRead==-1){
        perror("Eroare la citirea caii catre fisier.");
        exit(EXIT_FAILURE);
    }
    filePath[strcspn(filePath, "\n")] = '\0';

    int dim=strlen(filePath);
    char dimen[5];
    sprintf(dimen,"%d",dim);

    strcpy(commandBuf,dimen);
    strcat(commandBuf,";");
    strcat(commandBuf,filePath);

    dim=strlen(commandBuf);

    int bytesSend=send(client_socket,&dim,sizeof(int),0);
    if(bytesSend==-1){
        perror("Eroare la trimiterea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    bytesSend=send(client_socket,commandBuf,dim,0);
    if(bytesSend==-1){
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    } 

    uint32_t recvStatus;
    recv(client_socket,&recvStatus,sizeof(recvStatus),0);
    uint32_t status=ntohl(recvStatus);
    
    if(status==0x0){
        printf("Operatia s-a realizat cu succes.\n");
    }
    else if(status==0x40){
        printf("S-a produs o eroare in cadrul operatiei.\n");
    } 
}

void MOVE_Command()
{
    char commandBuf[MAX_SIZE];
    printf("\n---MOVE---\n");
    printf("Introduceti calea fisierului pe care doriti sa il mutati:\n");
    char filePath[250];
    int bytesRead=read(0,filePath,sizeof(filePath));
    if(bytesRead==-1){
        perror("Eroare la citirea caii catre fisier.");
        exit(EXIT_FAILURE);
    }
    filePath[strcspn(filePath, "\n")] = '\0';
    int dim=strlen(filePath);
    char dimen[4];
    sprintf(dimen,"%d",dim);
    strcpy(commandBuf,dimen);
    strcat(commandBuf,";");
    strcat(commandBuf,filePath);
    strcat(commandBuf,";");

    char* name=getFileNameFromPath(filePath);

    printf("Introduceti noul director:\n");
    char directory[250];
    bytesRead=read(0,directory,sizeof(directory));
    if(bytesRead==-1){
        perror("Eroare la citirea caii catre fisier.");
        exit(EXIT_FAILURE);
    }
    
    directory[strcspn(directory, "\n")] = '\0';
    char path[300];

    char currentPath[MAX_SIZE];
    if (getcwd(currentPath, sizeof(currentPath)) == NULL) {
        perror("Eroare in obtinerea directorului curent.");
        exit(EXIT_FAILURE);
    }
    char absolutePath[MAX];
    snprintf(absolutePath, sizeof(absolutePath), "%s/%s", currentPath, SERVER_DIRECTORY);
    
    if(strcmp(directory,"DocumentsServer")==0){
        
        strcpy(path,absolutePath);
        strcat(path,"/");
        strcat(path,name);

        dim=strlen(path);
        sprintf(dimen,"%d",dim);
        strcat(commandBuf,dimen);
        strcat(commandBuf,";");
        strcat(commandBuf,path);
        
    }
    else{
        strcpy(path,absolutePath);
        strcat(path,"/");
        strcat(path,directory);
        strcat(path,"/");
        strcat(path,name);

        dim=strlen(path);
        sprintf(dimen,"%d",dim);
        strcat(commandBuf,dimen);
        strcat(commandBuf,";");   
        strcat(commandBuf,path);
    }

    dim=strlen(commandBuf);
    int bytesSend=send(client_socket,&dim,sizeof(int),0);
    if(bytesSend==-1){
        perror("Eroare la trimiterea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    bytesSend=send(client_socket,commandBuf,dim,0);
    if(bytesSend==-1){
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    } 

    uint32_t recvStatus;
    recv(client_socket,&recvStatus,sizeof(recvStatus),0);
    uint32_t status=ntohl(recvStatus);
    
    if(status==0x0){
        printf("Operatia s-a realizat cu succes.\n");
    }
    else if(status==0x40){
        printf("S-a produs o eroare in cadrul operatiei.\n");
    } 
}

void UPDATE_Command()
{
    printf("\n---UPDATE---\n");
    printf("Tastati calea fisierului pe care doriti sa-l actualizati:\n");
    char filePath[250];
    int bytesRead = read(0, filePath, sizeof(filePath));
    if (bytesRead == -1) {
        perror("Eroare la citirea caii catre fisier.");
        exit(EXIT_FAILURE);
    }
    filePath[strcspn(filePath, "\n")] = '\0';

    char commandBuf[MAX];
    int dim = strlen(filePath);
    char dimen[5];
    sprintf(dimen, "%d", dim);

    strcpy(commandBuf, dimen);
    strcat(commandBuf, ";");
    strcat(commandBuf,filePath);
    strcat(commandBuf,";");

    printf("Introduceti octetul de start:\n");
    char byte[5];
    bytesRead=read(0,byte,sizeof(byte));
    if(bytesRead==-1){
        perror("Eroare la citirea octetului de start.");
        exit(EXIT_FAILURE);
    }
    
    byte[strcspn(byte, "\n")] = '\0';
    strcat(commandBuf,byte);
    strcat(commandBuf,";");

    printf("Introduceti textul dorit:\n");
    char text[MAX_SIZE];
    bytesRead=read(0,text,sizeof(text));
    if(bytesRead==-1){
        perror("Eroare la citirea textului dorit.");
        exit(EXIT_FAILURE);
    }
    text[strcspn(text,"\n")]='\0';
    dim=strlen(text);
    sprintf(dimen, "%d", dim);

    strcat(commandBuf, dimen);
    strcat(commandBuf, ";");
    strcat(commandBuf,text);


    dim = strlen(commandBuf);
    int bytesSend = send(client_socket, &dim, sizeof(int), 0);
    if (bytesSend == -1) {
        perror("Eroare la trimiterea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    bytesSend = send(client_socket, commandBuf, dim, 0);
    if (bytesSend == -1) {
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    }

    uint32_t recvStatus;
    recv(client_socket,&recvStatus,sizeof(recvStatus),0);
    uint32_t status=ntohl(recvStatus);
    
    if(status==0x0){
        printf("Operatia s-a realizat cu succes.\n");
    }
}

void SEARCH_Command()
{
    printf("\n---SEARCH---\n");
    printf("Tastati cuvantul pe care doriti sa il cautati:\n");
    char word[50];
    int bytesRead = read(0, word, sizeof(word));
    if (bytesRead == -1) {
        perror("Eroare la citirea cuvantului.");
        exit(EXIT_FAILURE);
    }
    word[strcspn(word, "\n")] = '\0';

    char commandBuf[MAX];
    int dim = strlen(word);
    char dimen[5];
    sprintf(dimen, "%d", dim);

    strcpy(commandBuf, dimen);
    strcat(commandBuf, ";");
    strcat(commandBuf,word);
    strcat(commandBuf,";");

    dim = strlen(commandBuf);
    int bytesSend = send(client_socket, &dim, sizeof(int), 0);
    if (bytesSend == -1) {
        perror("Eroare la trimiterea dimensiunii comenzii.");
        exit(EXIT_FAILURE);
    }
    bytesSend = send(client_socket, commandBuf, dim, 0);
    if (bytesSend == -1) {
        perror("Eroare la trimiterea comenzii.");
        exit(EXIT_FAILURE);
    }

    uint32_t recvStatus;
    recv(client_socket,&recvStatus,sizeof(recvStatus),0);
    uint32_t status=ntohl(recvStatus);

    if(status==0x1){
        printf("Nu exista fisiere care sa contina cuvantul.\n");
    }
    else if(status==0x0)
    {
        int sentBytes=recv(client_socket,&dim,sizeof(int),0);
        if(sentBytes==-1){
            perror("Eroare la primirea dimensiunii comenzii.\n");
            exit(EXIT_FAILURE);
        }

        char* commandRecv=(char*)malloc(sizeof(char)*dim);
        if(commandRecv==NULL){
            perror("Eroare la alocarea memoriei.");
            exit(EXIT_FAILURE);
        }

        sentBytes=recv(client_socket,commandRecv,dim,0);
        if(sentBytes==-1){
            perror("Eroare la primirea comenzii.");
            exit(EXIT_FAILURE);
        }
        commandRecv[dim]='\0';

        char* p=strtok(commandRecv,";");
        dim=atoi(p);
        char* files=(char*)malloc(sizeof(char)*dim);
        if(files==NULL){
            perror("Eroare la alocarea fisierelor.");
        }
        p=strtok(NULL,";");
        strcpy(files,p);
        printf("Fisierele care contin cuvantul '%s' sunt:\n",word);
        p=strtok(files,"*");
        while(p!=NULL){
            printf("%s\n",p);
            p=strtok(NULL,"*");
        }
        
        free(files);
        free(commandRecv);
    }
}

void* sendCommand(void* arg)
{
   
    do
    {
        printf("\n--------MENIU--------\n");
        printf("--->1.LIST\n");
        printf("--->2.DOWNLOAD\n");
        printf("--->3.UPLOAD\n");
        printf("--->4.DELETE\n");
        printf("--->5.MOVE\n");
        printf("--->6.UPDATE\n");
        printf("--->7.SEARCH\n");
        printf("Introduceti numarul optiunii pe care o doriti:");
  
        int command=-1;
        uint32_t cmd;
        scanf("%d",&command);
        /*uint32_t recvC;
        int bytesRead;

        if((bytesRead=recv(client_socket,&recvC,sizeof(recvC),0))<0){
            continue;
        }
        else if((bytesRead=recv(client_socket,&recvC,sizeof(recvC),0))>0){
            uint32_t exitC=ntohl(recvC);
            printf("\nDeconectare de la server.\n");
            close(client_socket);
            exit(EXIT_SUCCESS);
        }*/
        switch(command)
        {
            case 1:
                cmd=0x0;
                break;
            case 2:
                cmd=0x1;
                break;
            case 3:
                cmd=0x2;
                break;
            case 4:
                cmd=0x4;
                break;
            case 5:
                cmd=0x8;
                break;
            case 6:
                cmd=0x10;
                break;
            case 7:
                cmd=0x20;
                break;
            default:
                break;
        }
        
        uint32_t toSend=htonl(cmd);
        send(client_socket,&toSend,sizeof(toSend),0);
        switch(cmd)
        {
            case 0x0:
                LIST_Command();
                break;
            case 0x1:
                DOWNLOAD_Command();
                break;
            case 0x2:
                UPLOAD_Command();
                break;
            case 0x4:
                DELETE_Command();
                break;
            case 0x8:
                MOVE_Command();
                break;
            case 0x10:
                UPDATE_Command();
                break;
            case 0x20:
                SEARCH_Command();
                break;
            default:
                break;
        }


    }while(serverRunning);

    return NULL;
}

int main()
{
    struct sockaddr_in server_address;

    if((client_socket = socket(AF_INET, SOCK_STREAM, 0))==-1){
        perror("Eroare in crearea socketului.");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family=AF_INET;
    server_address.sin_port=htons(SERVERPORT);

    if(inet_pton(AF_INET,SERVERIP,&server_address.sin_addr)==-1){
        perror("Eroare la transformarea adresei IP.");
        exit(EXIT_FAILURE);
    }

    if(connect(client_socket,(struct sockaddr*)&server_address,sizeof(server_address))==-1){
        perror("Eroare la conectare.");
        exit(EXIT_FAILURE);
    }
    
    uint32_t recvS;
    recv(client_socket,&recvS,sizeof(recvS),0);
    uint32_t status=ntohl(recvS);

    if(status==0x0){
        printf("Conexiunea la server s-a realizat cu succes.\n");
    }
    else if(status=0x8){
        printf("Serverul este full.");
        close(client_socket);
        exit(EXIT_SUCCESS);
    }

    if(pthread_create(&sendThread,NULL,sendCommand,NULL)!=0)
    {
        perror("Eroare la crearea threadului.");
        exit(EXIT_FAILURE);
    }
   
    pthread_join(sendThread,NULL);
    close(client_socket);
    return 0;
}

